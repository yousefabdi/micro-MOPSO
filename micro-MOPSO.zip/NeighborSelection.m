function pop = NeighborSelection( auxilary, leader, nPop )

    for k=1:numel(auxilary)
        auxilary(k).ED  = sqrt(sum((leader.Cost - auxilary(k).Cost) .^ 2));
    end
    
    dists=[auxilary.ED];
    [~, ind]=sort(dists);
    auxilary=auxilary(ind);
    pop=auxilary(1:nPop-1);
    pop(nPop)=leader;
    
end

