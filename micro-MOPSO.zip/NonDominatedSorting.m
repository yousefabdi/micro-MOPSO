function [pop F]=NonDominatedSorting(pop)

    nPop=numel(pop);

    F{1}=[];
    
    cr=[pop.Cost];
    for i=1:nPop
        pop(i).DominatedCount=0;
        pop(i).DominationSet=[];
        c=pop(i).Cost;        
        %ind1=find((cr(1,:)<c(1) & cr(2,:)<=c(2))|(cr(1,:)<=c(1) & cr(2,:)<c(2)));
        ind1=find(all(cr<=c) & any(cr<c));
        %ind2=find((cr(1,:)>c(1) & cr(2,:)>=c(2))|(cr(1,:)>=c(1) & cr(2,:)>c(2)));
        ind2=find(all(cr>=c) & any(cr>c));
        
                pop(i).DominationSet=ind2;

                pop(i).DominatedCount=pop(i).DominatedCount+numel(ind1);
                
        
        if pop(i).DominatedCount==0
            
        end
        
    end
    temp=[pop.DominatedCount];
    F{1}=find(temp==0);
    
    k=1;
    
    while true
        
        Q=[];
        
        for i=F{k}
            for j=pop(i).DominationSet
                pop(j).DominatedCount=pop(j).DominatedCount-1;
                
                if pop(j).DominatedCount==0
                    Q=[Q j];
                end
            end
        end
        
        if isempty(Q)
            break;
        end
        
        F{k+1}=Q;
        k=k+1;
        
    end
    
    for k=1:numel(F)
        for i=F{k}
            pop(i).Rank=k;
        end
    end
    
end