function rep=CalcCrowdingDistance(rep)

    if isempty(rep)
        return;
    end
       
    CrowdDis = zeros(1,numel(rep));
    if numel(rep)>=2
        costs=[rep.Cost]';
        Fmax = max(costs,[],1);
        Fmin = min(costs,[],1);
        for i=1:size(costs,2)
           [~,rank] = sortrows(costs(:,i));
            CrowdDis(rank(1))   = 5;
            CrowdDis(rank(end)) = 5; 
            for j = 2 : size(costs,1)-1
                CrowdDis(rank(j)) = CrowdDis(rank(j))+(costs(rank(j+1),i)-costs(rank(j-1),i))/(Fmax(i)-Fmin(i));
            end
        end
        for j = 1 : size(costs,1)
            rep(j).CrowdingDistance=CrowdDis(j);
        end
    else
        rep(1).CrowdingDistance=5;
    end
    
end