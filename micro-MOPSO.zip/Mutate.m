function xnew=Mutate(x,mu,VarMin,VarMax, t, MaxIt)

    nVar=numel(x);
    sel=ceil(nVar*mu);
    inds=randsample(nVar,sel);
    
    for k=1:numel(inds)
        if rand<=0.5
            x(inds(k))=x(inds(k))+(VarMax(inds(k))-x(inds(k)))*(1-unifrnd(0,1)^((1-(t/MaxIt))^5));
        else
            x(inds(k))=x(inds(k))-(x(inds(k))-VarMin(inds(k)))*(1-unifrnd(0,1)^((1-(t/MaxIt))^5));
        end
    end
       
    xnew=x;

end