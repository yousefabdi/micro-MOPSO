%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%  Micro Multi-objective Particle Swarm Optimization
%%%%%%%%%%%  Programmed By: Yousef Abdi
%%%%%%%%%%%  E-mail: yousef.abdi@gmail.com, y.abdi@tabrizu.ac.ir
%%%%%%%%%%%  November 2020
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc;
clear;
close all;
%% Problem Definition
for Problem=[1 2 3 4 6]
    %%  Globalization of Parameters and Settings 
    prob=num2str(Problem);
    CostFunction=str2func(['@(x)  ZDT' prob '(x)']);  %Cost Function
    load(['Problem_PFs\ZDT' prob '.mat']);
    %load(['..\Problem_PFs\ZDT' prob ]);
    %problemName=['DTLZ' prob '_2'];
    problemName=['ZDT' prob];
    
    switch Problem
        case num2cell([1 2 3])
            nVar=30;            
            VarMin(1:nVar)=0;
            VarMax(1:nVar)=1;
        case 4
            nVar=10;
            VarMin(1:nVar)=0;
            VarMax(1:nVar)=1;
            VarMin(2:nVar)=-5;
            VarMax(2:nVar)=5;
        case 6
            nVar=10;
            VarMin(1:nVar)=0;
            VarMax(1:nVar)=1;          
    end
    VarSize=[1 nVar];       
%% MOPSO Parameters

    MaxIt=2000;           % Maximum Number of Iterations

    nPop=5;            % Population Size

    nRep=100;            % Repository Size

    w=0.72;              % Inertia Weight
    c1=1.8;               % Personal Learning Coefficient
    c2=1.8;               % Global Learning Coefficient
    gr=6;
    prt=2;
    alpha=0.1;          % Inflation Rate

    beta=0.2;             % Leader Selection Pressure

    mu=0.1;             % Mutation Rate
    TotalRun=30;
    %% Initialization

    empty_particle.Position=[];
    empty_particle.Velocity=[];
    empty_particle.Cost=[];
    empty_particle.Best.Position=[];
    empty_particle.Best.Cost=[];
    empty_particle.IsDominated=[];
    empty_particle.CrowdingDistance=[];
    empty_particle.CrowdingDistance=[];
    empty_particle.DominationSet=[];
    empty_particle.DominatedCount=0;
    empty_particle.ED=0;
    empty_particle.Rank=0;

    IGDs=zeros(MaxIt, TotalRun);
    HVs=zeros(MaxIt, TotalRun);

    for run=1:TotalRun
        pop=repmat(empty_particle,nPop,1);
        for i=1:nPop

            pop(i).Position=unifrnd(VarMin,VarMax,VarSize);

            pop(i).Velocity=zeros(VarSize);

            pop(i).Cost=CostFunction(pop(i).Position);


            % Update Personal Best
            pop(i).Best.Position=pop(i).Position;
            pop(i).Best.Cost=pop(i).Cost;

        end

        % Determine Domination
        pop=DetermineDomination(pop);

        rep=pop(~[pop.IsDominated]);
        rep=CalcCrowdingDistance(rep);
        auxilary=pop;

        %% MOPSO Main Loop

        for it=1:MaxIt
            w=rand;         
            leader=SelectLeader(rep,beta);
            pop = NeighborSelection( auxilary, leader, nPop );
            pop=DetermineDomination(pop);
            if (rem(it,5)==0)
                NonDom_Ind=find(~[pop.IsDominated]==1);
                if numel(NonDom_Ind)>=2
                    for k=1:2
                        pop(NonDom_Ind(k)).Position=unifrnd(VarMin,VarMax,VarSize);
                        pop(NonDom_Ind(k)).Velocity=zeros(VarSize);
                        pop(NonDom_Ind(k)).Cost=CostFunction(pop(NonDom_Ind(k)).Position);
                    end
                elseif numel(NonDom_Ind)==1
                    pop(NonDom_Ind).Position=unifrnd(VarMin,VarMax,VarSize);
                    pop(NonDom_Ind).Cost=CostFunction(pop(NonDom_Ind).Position);
                end
            end

            for i=1:nPop

                pop(i).Velocity = w.*pop(i).Velocity ...
                    +c1*rand(VarSize).*(pop(i).Best.Position-pop(i).Position) ...
                    +c2*rand(VarSize).*(leader.Position-pop(i).Position);

                pop(i).Position = pop(i).Position + pop(i).Velocity;

                % Apply Mutation
                pop(i).Position=Mutate(pop(i).Position,mu,VarMin,VarMax, it, MaxIt);            
                %----------------
                pop(i).Position = max(pop(i).Position, VarMin);
                pop(i).Position = min(pop(i).Position, VarMax);

                pop(i).Cost = CostFunction(pop(i).Position);

                if Dominates(pop(i),pop(i).Best)
                    pop(i).Best.Position=pop(i).Position;
                    pop(i).Best.Cost=pop(i).Cost;
                end
                auxilary=[auxilary
                            pop(i)];

            end

            pop=DetermineDomination(pop);

            % Add Non-Dominated Particles to REPOSITORY
            rep=[rep
                 pop(~[pop.IsDominated])]; %#ok

            % Determine Domination of New Resository Members
            rep=DetermineDomination(rep);

            % Keep only Non-Dminated Memebrs in the Repository
            rep=rep(~[rep.IsDominated]);

            rep=CalcCrowdingDistance(rep);               

            % Check if Repository is Full
            if numel(rep)>nRep

                Extra=numel(rep)-nRep;
                rep=DeleteRep(rep,nRep);

            end
            if numel(auxilary)>200        
                [auxilary F]=NonDominatedSorting(auxilary);
                if(numel(F)>5)
                    del_ind=[];
                   for PFc=numel(F):-1:6
                       del_ind=[del_ind F{PFc}];                   
                   end
                   auxilary(del_ind)=[];
                end
            end

            IGDs(it,run)=IGD([rep.Cost]',PF);
            HVs(it,run)=HV([rep.Cost]',PF);

            % Plot Costs
            figure(1);
            PlotCosts(pop,rep);
            pause(0.001);

            % Show Iteration Information
            disp(['Problem= ' num2str(Problem) ' : Run : ' num2str(run) ' Iteration ' num2str(it) ': Number of Rep Members = ' num2str(numel(rep))]);

        end
        Rep_Whole{run}=rep;
        % Save The results
        save(['D://Micro-MOPSO_' problemName '_10000NFE.mat'],'HVs','IGDs', 'Rep_Whole');
    end
end
