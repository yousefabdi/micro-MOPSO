function leader=SelectLeader(rep,beta)
    
    N=[rep.CrowdingDistance];    
    [N,sortInd]=sort(N, 'descend');

    rep=(rep(sortInd));
    
    ind=1:(ceil(numel(N)*beta));
    r=randsample(ind,1);
          
    % Leader
    leader=rep(r);

end